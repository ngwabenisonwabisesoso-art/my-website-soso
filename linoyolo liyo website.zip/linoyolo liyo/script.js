/* =================================
   TYPING EFFECT
================================= */

const typingElement = document.getElementById("typing");

const words = [
    "Software Developer 💻",
    "AI Enthusiast 🤖",
    "Programmer 👩🏽‍💻",
    "Entrepreneur 🌸",
    "Creative Dreamer 🎀"
];

let wordIndex = 0;
let characterIndex = 0;
let deleting = false;


function typeEffect() {

    if (!typingElement) {
        return;
    }

    const currentWord = words[wordIndex];

    if (!deleting) {

        typingElement.textContent =
            currentWord.substring(
                0,
                characterIndex + 1
            );

        characterIndex++;

        if (characterIndex === currentWord.length) {

            deleting = true;

            setTimeout(typeEffect, 1500);

            return;
        }

    } else {

        typingElement.textContent =
            currentWord.substring(
                0,
                characterIndex - 1
            );

        characterIndex--;

        if (characterIndex === 0) {

            deleting = false;

            wordIndex++;

            if (wordIndex === words.length) {
                wordIndex = 0;
            }

        }

    }

    const speed = deleting ? 50 : 100;

    setTimeout(typeEffect, speed);
}


typeEffect();



/* =================================
   EMOJI RAIN
================================= */

const emojiContainer =
    document.getElementById("emojiRain");


const emojis = [
    "💜",
    "💗",
    "💕",
    "🎀",
    "✨",
    "🌸",
    "💖",
    "⭐",
    "🦋"
];


function createEmoji() {

    if (!emojiContainer) {
        return;
    }

    const emoji =
        document.createElement("div");

    emoji.classList.add("rain-emoji");

    emoji.textContent =
        emojis[
            Math.floor(
                Math.random() * emojis.length
            )
        ];

    emoji.style.left =
        Math.random() * 100 + "vw";

    emoji.style.fontSize =
        (Math.random() * 18 + 12) + "px";

    emoji.style.animationDuration =
        (Math.random() * 5 + 5) + "s";

    emoji.style.opacity =
        Math.random() * 0.6 + 0.3;

    emojiContainer.appendChild(emoji);


    setTimeout(() => {

        emoji.remove();

    }, 10000);

}


setInterval(createEmoji, 350);



/* =================================
   GALLERY LIGHTBOX
================================= */

function openLightbox(imageSource) {

    const lightbox =
        document.getElementById("lightbox");

    const image =
        document.getElementById("lightboxImage");

    if (!lightbox || !image) {
        return;
    }

    image.src = imageSource;

    lightbox.style.display = "flex";

}


function closeLightbox() {

    const lightbox =
        document.getElementById("lightbox");

    if (lightbox) {

        lightbox.style.display = "none";

    }

}


/* =================================
   CLOSE LIGHTBOX BY CLICKING OUTSIDE
================================= */

const lightbox =
    document.getElementById("lightbox");


if (lightbox) {

    lightbox.addEventListener(
        "click",
        function(event) {

            if (event.target === lightbox) {

                closeLightbox();

            }

        }
    );

}


/* =================================
   ESC KEY CLOSES IMAGE
================================= */

document.addEventListener(
    "keydown",
    function(event) {

        if (event.key === "Escape") {

            closeLightbox();

        }

    }
);